
# hgnjackknife v0.4.4: decouple center ("mle"/"jkbc") and ref_dist ("normal"/"t")

.logsumexp <- function(z) { m <- max(z); m + log(sum(exp(z - m))) }
.fmt_p   <- function(p, digits = 3) {
  if (is.na(p)) return("NA")
  if (!is.finite(p)) return("NA")
  if (p <= 0) return("0")
  cut <- 10^(-(digits+1))
  if (p < cut) return(paste0("<", format(cut, scientific = TRUE)))
  formatC(p, format = "f", digits = digits)
}
.fmt_num <- function(x, digits = 3) formatC(x, format = "fg", digits = digits)
.rule <- function(ch = getOption("hgnjackknife.rule_char", "-"), width = getOption("width", 80)) {
  paste(rep(ch, width), collapse = "")
}
.wald_p_two_sided <- function(estimate, se, df = NULL) {
  if (!is.finite(se) || se <= 0) return(NA_real_)
  z <- estimate / se
  if (is.null(df)) 2 * (1 - stats::pnorm(abs(z))) else 2 * (1 - stats::pt(abs(z), df = df))
}

# Conditional log-likelihood for a single study (log-OR)
.study_loglik_or_cond <- function(theta, d1, n1, d2, n2) {
  m <- d1 + d2
  lo <- max(0, m - n2); hi <- min(n1, m)
  xs <- lo:hi
  log_w <- lchoose(n1, xs) + lchoose(n2, m - xs)
  log_norm <- .logsumexp(log_w + theta * xs)
  d1 * theta - log_norm
}

# ----- Random-effects MLE -----
hgn_fit <- function(d1, n1, d2, n2,
                    gh_points = 30,
                    start_mu = 0,
                    start_log_tau = -2,
                    control = list(maxit = 300, reltol = 1e-9, trace = 0),
                    jk_for_tests = TRUE,
                    center = c("mle","jkbc"),
                    ref_dist = c("normal","t")) {
  center <- match.arg(center)
  ref_dist <- match.arg(ref_dist)
  if (!requireNamespace("statmod", quietly = TRUE)) stop('Please install.packages("statmod")')
  stopifnot(length(d1) == length(n1), length(d2) == length(n2), length(d1) == length(d2))
  k <- length(d1)
  gh <- statmod::gauss.quad.prob(gh_points, "normal")
  nodes <- gh$nodes; wts <- gh$weights

  nll <- function(par) {
    mu  <- par[1]; tau <- exp(par[2]); if (!is.finite(tau)) return(1e100)
    ll_sum <- 0
    for (i in seq_len(k)) {
      logf <- vapply(nodes, function(u) {
        th <- mu + tau * u
        .study_loglik_or_cond(th, d1[i], n1[i], d2[i], n2[i])
      }, numeric(1))
      ll_i <- .logsumexp(log(wts) + logf); if (!is.finite(ll_i)) return(1e100)
      ll_sum <- ll_sum + ll_i
    }
    -ll_sum
  }

  par0 <- c(start_mu, start_log_tau)
  opt  <- stats::optim(par0, nll, method = "BFGS", control = control)
  mu_hat  <- opt$par[1]; tau_hat <- exp(opt$par[2]); ll_re <- -opt$value

  # Optional jackknife for tests
  se_mu_jk <- se_tau_jk <- NA_real_
  mu_loo <- tau_loo <- NULL
  mu_jk_bc <- NA_real_
  if (jk_for_tests || center == "jkbc") {
    mu_loo  <- tau_loo <- rep(NA_real_, k)
    for (i in seq_len(k)) {
      idx <- (seq_len(k) != i)
      fit_i <- hgn_fit(d1[idx], n1[idx], d2[idx], n2[idx],
                       gh_points = gh_points,
                       start_mu = mu_hat,
                       start_log_tau = log(pmax(tau_hat, 1e-6)),
                       control = control,
                       jk_for_tests = FALSE,
                       center = "mle",
                       ref_dist = ref_dist)
      mu_loo[i]  <- fit_i$mu
      tau_loo[i] <- fit_i$tau
    }
    mu_bar <- mean(mu_loo)
    var_mu_jk <- (k - 1) / k * sum((mu_loo - mu_bar)^2)
    se_mu_jk  <- sqrt(var_mu_jk)
    mu_jk_bc  <- k * mu_bar - (k - 1) * mu_hat

    eps <- 1e-8
    z_loo <- log(pmax(tau_loo, eps))
    z_bar <- mean(z_loo)
    var_z_jk <- (k - 1) / k * sum((z_loo - z_bar)^2)
    se_z_jk  <- sqrt(var_z_jk)
    se_tau_jk <- se_z_jk * tau_hat
  }

  # Wald(JK) for mu with chosen center/ref_dist
  df <- if (ref_dist == "t") (k - 1) else NULL
  mu_center <- if (center == "jkbc" && is.finite(mu_jk_bc)) mu_jk_bc else mu_hat
  if (is.na(se_mu_jk) || se_mu_jk <= 0) { z_mu <- NA_real_; p_mu <- NA_real_ } else {
    z_mu <- mu_center / se_mu_jk
    p_mu <- .wald_p_two_sided(mu_center, se_mu_jk, df = df)
  }

  # tau test (boundary): normal one-sided/two-sided
  z_tau <- if (is.na(se_tau_jk) || se_tau_jk <= 0) NA_real_ else tau_hat / se_tau_jk
  p_tau_one <- if (is.na(z_tau)) NA_real_ else (1 - stats::pnorm(z_tau))
  p_tau_two <- if (is.na(z_tau)) NA_real_ else 2 * (1 - stats::pnorm(abs(z_tau)))

  obj <- list(mu = mu_hat,
              tau = tau_hat, tau2 = tau_hat^2,
              loglik = ll_re,
              z_mu_wald = z_mu, p_mu_wald = p_mu,
              z_tau_wald = z_tau, p_tau_wald_one_sided = p_tau_one, p_tau_wald_two_sided = p_tau_two,
              se_mu_jk = se_mu_jk, se_tau_jk = se_tau_jk,
              mu_jk_bias_corrected = mu_jk_bc,
              convergence = (opt$convergence == 0),
              counts = opt$counts, message = opt$message,
              gh_points = gh_points,
              center = center, ref_dist = ref_dist)
  class(obj) <- c("hgn_fit", "hgnjackknife")
  obj
}

# ----- Random-effects Jackknife -----
hgn_jackknife <- function(d1, n1, d2, n2,
                          gh_points = 30,
                          start_mu = 0,
                          start_log_tau = -2,
                          alpha = 0.05,
                          center = c("jkbc","mle"),
                          ref_dist = c("t","normal"),
                          control = list(maxit = 300, reltol = 1e-9, trace = 0)) {
  center <- match.arg(center)
  ref_dist <- match.arg(ref_dist)
  k <- length(d1)
  fit_full <- hgn_fit(d1, n1, d2, n2, gh_points, start_mu, start_log_tau, control,
                      jk_for_tests = FALSE, center = "mle", ref_dist = ref_dist)
  mu_hat <- fit_full$mu; tau_hat <- fit_full$tau

  mu_loo  <- tau_loo <- tau2_loo <- rep(NA_real_, k)
  for (i in seq_len(k)) {
    idx <- (seq_len(k) != i)
    fit_i <- hgn_fit(d1[idx], n1[idx], d2[idx], n2[idx],
                     gh_points = gh_points,
                     start_mu = mu_hat,
                     start_log_tau = log(pmax(tau_hat, 1e-6)),
                     control = control,
                     jk_for_tests = FALSE,
                     center = "mle",
                     ref_dist = ref_dist)
    mu_loo[i]   <- fit_i$mu
    tau_loo[i]  <- fit_i$tau
    tau2_loo[i] <- fit_i$tau^2
  }

  mu_bar    <- mean(mu_loo)
  var_mu_jk <- (k - 1) / k * sum((mu_loo - mu_bar)^2)
  se_mu_jk  <- sqrt(var_mu_jk)

  eps   <- 1e-8
  z_loo <- log(pmax(tau_loo, eps))
  z_bar <- mean(z_loo)
  var_z_jk <- (k - 1) / k * sum((z_loo - z_bar)^2)
  se_z_jk  <- sqrt(var_z_jk)

  se_tau_jk   <- se_z_jk * tau_hat
  var_tau2_jk <- (2 * tau_hat)^2 * se_tau_jk^2
  se_tau2_jk  <- sqrt(var_tau2_jk)

  mu_jk_bc <- k * mu_bar - (k - 1) * mu_hat
  df <- if (ref_dist == "t") (k - 1) else NULL
  mu_center <- if (center == "jkbc") mu_jk_bc else mu_hat

  qcrit <- if (ref_dist == "t") stats::qt(1 - alpha/2, df = k - 1) else stats::qnorm(1 - alpha/2)
  ci_mu <- c(mu_center - qcrit * se_mu_jk, mu_center + qcrit * se_mu_jk)

  z_mu  <- if (se_mu_jk <= 0) NA_real_ else mu_center / se_mu_jk
  p_mu  <- .wald_p_two_sided(mu_center, se_mu_jk, df = df)

  z_tau <- if (se_tau_jk <= 0) NA_real_ else tau_hat / se_tau_jk
  p_tau_one <- if (is.na(z_tau)) NA_real_ else (1 - stats::pnorm(z_tau))
  p_tau_two <- if (is.na(z_tau)) NA_real_ else 2 * (1 - stats::pnorm(abs(z_tau)))

  obj <- list(mu = mu_hat,
              tau = tau_hat, tau2 = tau_hat^2,
              se_mu_jk = se_mu_jk, ci_mu = ci_mu,
              se_tau_jk = se_tau_jk, ci_tau = c(NA_real_, NA_real_),
              se_tau2_jk = se_tau2_jk, ci_tau2 = c(NA_real_, NA_real_),
              mu_jk_bias_corrected = mu_jk_bc,
              mu_loo = mu_loo, tau_loo = tau_loo, tau2_loo = tau2_loo,
              gh_points = gh_points, alpha = alpha,
              center = center, ref_dist = ref_dist,
              z_mu_wald = z_mu, p_mu_wald = p_mu,
              z_tau_wald = z_tau, p_tau_wald_one_sided = p_tau_one, p_tau_wald_two_sided = p_tau_two)
  class(obj) <- c("hgn_jackknife", "hgnjackknife")
  obj
}

# ----- Fixed-effect (tau=0) MLE -----
hgn_fit_fe <- function(d1, n1, d2, n2,
                       start_mu = 0,
                       control = list(maxit = 300, reltol = 1e-9, trace = 0),
                       jk_for_tests = TRUE,
                       center = c("mle","jkbc"),
                       ref_dist = c("normal","t")) {
  center <- match.arg(center)
  ref_dist <- match.arg(ref_dist)
  stopifnot(length(d1) == length(n1), length(d2) == length(n2), length(d1) == length(d2))
  k <- length(d1)

  nll_fe <- function(mu) {
    -sum(vapply(seq_len(k), function(i)
      .study_loglik_or_cond(mu, d1[i], n1[i], d2[i], n2[i]), numeric(1)))
  }
  opt <- stats::optim(par = start_mu, fn = nll_fe, method = "BFGS", control = control)
  mu_hat <- opt$par[1]; ll_fe <- -opt$value

  se_mu_jk <- NA_real_; mu_loo <- NULL; mu_jk_bc <- NA_real_
  if (jk_for_tests || center == "jkbc") {
    mu_loo <- rep(NA_real_, k)
    for (i in seq_len(k)) {
      idx <- (seq_len(k) != i)
      fit_i <- hgn_fit_fe(d1[idx], n1[idx], d2[idx], n2[idx],
                          start_mu = mu_hat, control = control, jk_for_tests = FALSE,
                          center = "mle", ref_dist = ref_dist)
      mu_loo[i] <- fit_i$mu
    }
    mu_bar <- mean(mu_loo)
    var_mu_jk <- (k - 1) / k * sum((mu_loo - mu_bar)^2)
    se_mu_jk  <- sqrt(var_mu_jk)
    mu_jk_bc  <- k * mu_bar - (k - 1) * mu_hat
  }
  df <- if (ref_dist == "t") (k - 1) else NULL
  mu_center <- if (center == "jkbc" && is.finite(mu_jk_bc)) mu_jk_bc else mu_hat
  if (!is.na(se_mu_jk) && se_mu_jk > 0 && (jk_for_tests || center == "jkbc")) {
    z_mu <- mu_center / se_mu_jk
    p_mu <- .wald_p_two_sided(mu_center, se_mu_jk, df = df)
  } else {
    z_mu <- NA_real_; p_mu <- NA_real_
  }

  obj <- list(mu = mu_hat,
              loglik = ll_fe,
              z_mu_wald = z_mu, p_mu_wald = p_mu,
              se_mu_jk = se_mu_jk,
              mu_jk_bias_corrected = mu_jk_bc,
              convergence = (opt$convergence == 0),
              counts = opt$counts, message = opt$message,
              center = center, ref_dist = ref_dist)
  class(obj) <- c("hgn_fit_fe", "hgnjackknife")
  obj
}

# ----- Fixed-effect jackknife -----
hgn_jackknife_fe <- function(d1, n1, d2, n2,
                             start_mu = 0,
                             alpha = 0.05,
                             center = c("jkbc","mle"),
                             ref_dist = c("t","normal"),
                             control = list(maxit = 300, reltol = 1e-9, trace = 0)) {
  center <- match.arg(center)
  ref_dist <- match.arg(ref_dist)
  k <- length(d1)

  fit_full <- hgn_fit_fe(d1, n1, d2, n2, start_mu, control, jk_for_tests = FALSE,
                         center = "mle", ref_dist = ref_dist)
  mu_hat   <- fit_full$mu

  mu_loo <- rep(NA_real_, k)
  for (i in seq_len(k)) {
    idx <- (seq_len(k) != i)
    fit_i <- hgn_fit_fe(d1[idx], n1[idx], d2[idx], n2[idx],
                        start_mu = mu_hat, control = control, jk_for_tests = FALSE,
                        center = "mle", ref_dist = ref_dist)
    mu_loo[i] <- fit_i$mu
  }

  mu_bar    <- mean(mu_loo)
  var_mu_jk <- (k - 1) / k * sum((mu_loo - mu_bar)^2)
  se_mu_jk  <- sqrt(var_mu_jk)
  mu_jk_bc  <- k * mu_bar - (k - 1) * mu_hat

  df <- if (ref_dist == "t") (k - 1) else NULL
  qcrit <- if (ref_dist == "t") stats::qt(1 - alpha/2, df = k - 1) else stats::qnorm(1 - alpha/2)
  mu_center <- if (center == "jkbc") mu_jk_bc else mu_hat
  ci_mu <- c(mu_center - qcrit * se_mu_jk, mu_center + qcrit * se_mu_jk)

  z_mu <- if (se_mu_jk <= 0) NA_real_ else mu_center / se_mu_jk
  p_mu <- .wald_p_two_sided(mu_center, se_mu_jk, df = df)

  obj <- list(mu = mu_hat,
              se_mu_jk = se_mu_jk, ci_mu = ci_mu,
              mu_jk_bias_corrected = mu_jk_bc,
              mu_loo = mu_loo,
              alpha = alpha,
              center = center, ref_dist = ref_dist,
              z_mu_wald = z_mu, p_mu_wald = p_mu)
  class(obj) <- c("hgn_jackknife_fe", "hgnjackknife")
  obj
}

# ---------- R and I^2 (Jackson-White-Riley 2012) ----------
hgn_ri2 <- function(d1, n1, d2, n2,
                    gh_points = 30,
                    alpha = 0.05,
                    ci_method = c("t","normal"),
                    ci_from   = c("R","I2"),
                    control = list(maxit = 300, reltol = 1e-9, trace = 0)) {
  ci_method <- match.arg(ci_method)
  ci_from   <- match.arg(ci_from)
  stopifnot(length(d1) == length(n1), length(d2) == length(n2), length(d1) == length(d2))
  k <- length(d1)

  jk_re <- hgn_jackknife(d1, n1, d2, n2,
                         gh_points = gh_points, control = control,
                         alpha = alpha, center = "jkbc", ref_dist = "t")
  jk_fe <- hgn_jackknife_fe(d1, n1, d2, n2,
                            start_mu = 0, control = control,
                            alpha = alpha, center = "jkbc", ref_dist = "t")

  se_re <- jk_re$se_mu_jk
  se_fe <- jk_fe$se_mu_jk
  if (!is.finite(se_re) || !is.finite(se_fe) || se_re <= 0 || se_fe <= 0) {
    warning("Non-finite or non-positive JK SEs; R and I^2 set to NA.")
    R_hat <- NA_real_; I2_raw <- NA_real_; I2_hat <- NA_real_
  } else {
    R_hat  <- se_re / se_fe
    I2_raw <- 1 - (se_fe^2 / se_re^2)
    I2_hat <- max(0, min(1, I2_raw))
  }

  R_loo  <- rep(NA_real_, k)
  I2_loo <- rep(NA_real_, k)
  for (i in seq_len(k)) {
    idx <- (seq_len(k) != i)
    jk_re_i <- hgn_jackknife(d1[idx], n1[idx], d2[idx], n2[idx],
                             gh_points = gh_points, control = control,
                             alpha = alpha, center = "jkbc", ref_dist = "t")
    jk_fe_i <- hgn_jackknife_fe(d1[idx], n1[idx], d2[idx], n2[idx],
                                start_mu = 0, control = control,
                                alpha = alpha, center = "jkbc", ref_dist = "t")
    se_re_i <- jk_re_i$se_mu_jk
    se_fe_i <- jk_fe_i$se_mu_jk
    if (is.finite(se_re_i) && is.finite(se_fe_i) && se_re_i > 0 && se_fe_i > 0) {
      R_loo[i]  <- se_re_i / se_fe_i
      I2_loo[i] <- 1 - (se_fe_i^2 / se_re_i^2)
    }
  }

  .jk_se <- function(x) {
    x <- x[is.finite(x)]
    if (length(x) < 2) return(NA_real_)
    kx <- length(x); xb <- mean(x)
    sqrt((kx - 1) / kx * sum((x - xb)^2))
  }

  se_R <- .jk_se(R_loo)
  R_bar <- mean(R_loo, na.rm = TRUE)
  qcrit <- if (ci_method == "t") stats::qt(1 - alpha/2, df = k - 1) else stats::qnorm(1 - alpha/2)
  R_bc <- if (is.finite(R_hat) && is.finite(R_bar)) k * R_bar - (k - 1) * R_hat else NA_real_
  ci_R <- if (is.finite(R_bc) && is.finite(se_R)) c(R_bc - qcrit * se_R, R_bc + qcrit * se_R) else c(NA_real_, NA_real_)
  if (is.finite(ci_R[1])) ci_R[1] <- max(ci_R[1], .Machine$double.eps)

  I2_from_R <- function(R) 1 - 1/(R^2)
  ci_I2_from_R <- if (is.finite(ci_R[1])) pmin(1, pmax(0, I2_from_R(ci_R))) else c(NA_real_, NA_real_)

  se_I2 <- .jk_se(I2_loo)
  I2_bar <- mean(I2_loo, na.rm = TRUE)
  I2_bc  <- if (is.finite(I2_hat) && is.finite(I2_bar)) k * I2_bar - (k - 1) * I2_hat else NA_real_
  ci_I2_dir <- if (is.finite(I2_bc) && is.finite(se_I2)) c(I2_bc - qcrit * se_I2, I2_bc + qcrit * se_I2) else c(NA_real_, NA_real_)
  ci_I2_dir <- pmin(1, pmax(0, ci_I2_dir))

  ci_I2 <- if (ci_from == "R") ci_I2_from_R else ci_I2_dir

  obj <- list(
    R = R_hat,
    se_R_jk = se_R,
    ci_R = ci_R,
    R_jk_bias_corrected = R_bc,
    R_loo = R_loo,
    I2 = I2_hat,
    I2_raw = I2_raw,
    se_I2_jk = se_I2,
    ci_I2 = ci_I2,
    I2_jk_bias_corrected = I2_bc,
    I2_loo = I2_loo,
    alpha = alpha, ci_method = ci_method, ci_from = ci_from,
    gh_points = gh_points
  )
  class(obj) <- c("hgn_ri2", "hgnjackknife")
  obj
}

# ---------- Printers ----------
print.hgn_fit <- function(x, digits = getOption("hgnjackknife.digits", 3), show_ratio = TRUE, ...) {
  cat("Hypergeometric-Normal RE fit (OR/RR)\n")
  cat(.rule(), "\n", sep = "")
  cat("mu (log OR/RR): ", .fmt_num(x$mu, digits), if (show_ratio) paste0("   [OR/RR=", .fmt_num(exp(x$mu), digits), "]"), "\n", sep = "")
  cat("tau:            ", .fmt_num(x$tau, digits), "   tau^2: ", .fmt_num(x$tau2, digits), "\n", sep = "")
  cat("logLik(RE):     ", .fmt_num(x$loglik, digits), "\n", sep = "")
  if (!is.null(x$z_tau_wald)) {
    cat("Wald(JK) tau=0 (one-sided): z=", .fmt_num(x$z_tau_wald, digits), "  p=", .fmt_p(x$p_tau_wald_one_sided, digits), "\n", sep = "")
  }
  if (!is.null(x$z_mu_wald)) {
    cat("Wald(JK) mu=0 (two-sided):  z=", .fmt_num(x$z_mu_wald, digits),  "  p=", .fmt_p(x$p_mu_wald, digits),
        "   [center=", x$center, ", ref=", x$ref_dist, "]", "\n", sep = "")
  }
  invisible(x)
}

summary.hgn_fit <- function(object, digits = getOption("hgnjackknife.digits", 3), ...) {
  out <- data.frame(
    parameter = c("mu (log OR/RR)", "OR/RR", "tau", "tau^2", "logLik(RE)"),
    estimate  = c(object$mu, exp(object$mu), object$tau, object$tau2, object$loglik),
    stringsAsFactors = FALSE
  )
  attr(out, "tests") <- data.frame(
    test = c("Wald(JK) tau=0 (one-sided)", paste0("Wald(JK) mu=0 (two-sided) [center=", object$center, ", ref=", object$ref_dist, "]")),
    z    = c(object$z_tau_wald, object$z_mu_wald),
    p    = c(object$p_tau_wald_one_sided, object$p_mu_wald)
  )
  class(out) <- c("summary_hgn_fit", "data.frame")
  out
}

print.summary_hgn_fit <- function(x, digits = getOption("hgnjackknife.digits", 3), ...) {
  cat("Summary: HGN RE fit (OR/RR)\n")
  cat(.rule(), "\n", sep = "")
  df <- as.data.frame(x); class(df) <- "data.frame"
  df$estimate <- .fmt_num(df$estimate, digits)
  print(df, row.names = FALSE, right = FALSE)
  cat("\nTests:\n")
  tst <- attr(x, "tests")
  tst2 <- as.data.frame(tst)
  tst2$z <- .fmt_num(tst2$z, digits)
  tst2$p <- vapply(tst2$p, .fmt_p, character(1), digits = digits)
  print(tst2, row.names = FALSE, right = FALSE)
  invisible(x)
}

print.hgn_jackknife <- function(x, digits = getOption("hgnjackknife.digits", 3), show_ratio = TRUE, ...) {
  cat("HGN RE jackknife (leave-one-study-out)\n")
  cat(.rule(), "\n", sep = "")
  cat("mu (log OR/RR): ", .fmt_num(x$mu, digits), sep = "")
  if (!is.null(x$ci_mu)) {
    cat("   SE(JK)=", .fmt_num(x$se_mu_jk, digits),
        "   CI(", 100*(1 - x$alpha), "%): [", .fmt_num(x$ci_mu[1], digits), ", ", .fmt_num(x$ci_mu[2], digits), "]", sep = "")
  }
  if (show_ratio && !is.null(x$ci_mu)) {
    cat("   [OR/RR CI: ", .fmt_num(exp(x$ci_mu[1]), digits), ", ", .fmt_num(exp(x$ci_mu[2]), digits), "]", sep = "")
  }
  cat("\n", sep = "")
  cat("tau:            ", .fmt_num(x$tau, digits), "\n", sep = "")
  if (!is.null(x$z_tau_wald)) {
    cat("Wald(JK) tau=0 (one-sided): z=", .fmt_num(x$z_tau_wald, digits), "  p=", .fmt_p(x$p_tau_wald_one_sided, digits), "\n", sep = "")
  }
  if (!is.null(x$z_mu_wald)) {
    cat("Wald(JK) mu=0 (two-sided):  z=", .fmt_num(x$z_mu_wald, digits),  "  p=", .fmt_p(x$p_mu_wald, digits),
        "   [center=", x$center, ", ref=", x$ref_dist, "]", "\n", sep = "")
  }
  invisible(x)
}

print.hgn_fit_fe <- function(x, digits = getOption("hgnjackknife.digits", 3), show_ratio = TRUE, ...) {
  cat("Hypergeometric-Normal FE fit (tau = 0; OR/RR)\n")
  cat(.rule(), "\n", sep = "")
  cat("mu (log OR/RR): ", .fmt_num(x$mu, digits), if (show_ratio) paste0("   [OR/RR=", .fmt_num(exp(x$mu), digits), "]"), "\n", sep = "")
  cat("logLik(FE):     ", .fmt_num(x$loglik, digits), "\n", sep = "")
  if (!is.null(x$z_mu_wald)) {
    cat("Wald(JK) mu=0 (two-sided):  z=", .fmt_num(x$z_mu_wald, digits),  "  p=", .fmt_p(x$p_mu_wald, digits),
        "   [center=", x$center, ", ref=", x$ref_dist, "]", "\n", sep = "")
  }
  invisible(x)
}

print.hgn_jackknife_fe <- function(x, digits = getOption("hgnjackknife.digits", 3), show_ratio = TRUE, ...) {
  cat("HGN FE jackknife (tau = 0; OR/RR)\n")
  cat(.rule(), "\n", sep = "")
  cat("mu (log OR/RR): ", .fmt_num(x$mu, digits),
      "   SE(JK)=", .fmt_num(x$se_mu_jk, digits),
      "   CI(", 100*(1 - x$alpha), "%): [", .fmt_num(x$ci_mu[1], digits), ", ", .fmt_num(x$ci_mu[2], digits), "]", sep = "")
  if (show_ratio) {
    cat("   [OR/RR CI: ", .fmt_num(exp(x$ci_mu[1]), digits), ", ", .fmt_num(exp(x$ci_mu[2]), digits), "]", sep = "")
  }
  cat("\n", sep = "")
  if (!is.null(x$z_mu_wald)) {
    cat("Wald(JK) mu=0 (two-sided):  z=", .fmt_num(x$z_mu_wald, digits),  "  p=", .fmt_p(x$p_mu_wald, digits),
        "   [center=", x$center, ", ref=", x$ref_dist, "]", "\n", sep = "")
  }
  invisible(x)
}

print.hgn_ri2 <- function(x, digits = getOption("hgnjackknife.digits", 3), ...) {
  cat("HGN R and I^2 (JK-based)\n")
  cat(.rule(), "\n", sep = "")
  cat("R = SE_RE(mu) / SE_FE(mu): ", .fmt_num(x$R, digits), sep = "")
  if (is.finite(x$se_R_jk)) {
    cat("   SE(JK)=", .fmt_num(x$se_R_jk, digits),
        "   CI(", 100*(1 - x$alpha), "%): [", .fmt_num(x$ci_R[1], digits), ", ", .fmt_num(x$ci_R[2], digits), "]",
        "\n", sep = "")
  } else cat("\n")
  cat("I^2 = 1 - 1/R^2:          ", .fmt_num(x$I2, digits), sep = "")
  if (all(is.finite(x$ci_I2))) {
    cat("   CI(", 100*(1 - x$alpha), "%): [", .fmt_num(x$ci_I2[1], digits), ", ", .fmt_num(x$ci_I2[2], digits), "]",
        "   (", x$ci_from, "-scale)", "\n", sep = "")
  } else cat("\n")
  invisible(x)
}
