# HGN 1.1-1 (2025-10-12)

- first version released on GitHub
